# System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER BROWSER                             │
│                                                                  │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │             React Frontend (Port 3000)                     │ │
│  │  ┌──────────────────────────────────────────────────────┐  │ │
│  │  │  Components:                                          │  │ │
│  │  │  • Target Event Input                                 │  │ │
│  │  │  • Related Events Manager                             │  │ │
│  │  │  • Analysis Display                                   │  │ │
│  │  │                                                        │  │ │
│  │  │  Styling: White & Gold Fintech Theme                  │  │ │
│  │  └──────────────────────────────────────────────────────┘  │ │
│  └────────────────────────────────────────────────────────────┘ │
│                              │                                   │
│                              │ HTTP Requests                     │
│                              ▼                                   │
└─────────────────────────────────────────────────────────────────┘
                               │
                               │ POST /api/analyze
                               │ { targetEvent, targetPrice, relatedEvents }
                               ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Node.js Backend (Port 5000)                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                  Express.js Server                         │ │
│  │  ┌──────────────────────────────────────────────────────┐  │ │
│  │  │  API Endpoints:                                       │  │ │
│  │  │  • POST /api/analyze  → Analyze events                │  │ │
│  │  │  • GET  /api/health   → Health check                  │  │ │
│  │  │  • GET  /api/polymarket/search → Search markets       │  │ │
│  │  └──────────────────────────────────────────────────────┘  │ │
│  │                                                              │ │
│  │  Environment Variables (.env):                               │ │
│  │  • GEMINI_API_KEY (stored securely server-side)             │ │
│  └────────────────────────────────────────────────────────────┘ │
│                              │                                   │
│                              │ API Request                       │
│                              ▼                                   │
└─────────────────────────────────────────────────────────────────┘
                               │
                               │
          ┌────────────────────┴────────────────────┐
          │                                         │
          ▼                                         ▼
┌──────────────────────┐              ┌──────────────────────┐
│   Google Gemini API  │              │  Polymarket Gamma    │
│                      │              │       API            │
│  Analyzes:           │              │                      │
│  • Event correlations│              │  Provides:           │
│  • Price validity    │              │  • Market data       │
│  • Returns verdict   │              │  • Event prices      │
└──────────────────────┘              └──────────────────────┘


Data Flow:
==========

1. User enters target event + related events in React frontend
2. Frontend sends data to Express backend via HTTP POST
3. Backend constructs prompt with event correlations
4. Backend calls Gemini API with prompt
5. Gemini analyzes correlations and returns verdict
6. Backend parses response and sends to frontend
7. Frontend displays verdict + analysis to user


Security:
=========

✅ API key stored in backend .env file only
✅ Never exposed to browser/client
✅ CORS configured for development
✅ Input validation on backend
