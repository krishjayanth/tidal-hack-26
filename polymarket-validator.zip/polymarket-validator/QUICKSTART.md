# Quick Start Guide

Get up and running in 5 minutes!

## Step 1: Get Gemini API Key (1 minute)

1. Go to [https://aistudio.google.com](https://aistudio.google.com)
2. Sign in with your Google account
3. Click "Get API key" → "Create API key"
4. Copy the API key

## Step 2: Setup Backend (2 minutes)

```bash
# Navigate to backend
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Edit .env and paste your API key
# GEMINI_API_KEY=paste_your_key_here

# Start the server
npm start
```

You should see: `Server running on port 5000`

## Step 3: Setup Frontend (2 minutes)

Open a **NEW terminal window**:

```bash
# Navigate to frontend
cd frontend

# Install dependencies
npm install

# Start the app
npm start
```

Your browser will automatically open to `http://localhost:3000`

## Step 4: Use the App!

1. **Target Event**: Enter "Will Trump win 2024 election?" and price "65"
2. **Related Events**: 
   - Add "Will Republicans win Senate?" at "72"
   - Add "Will Biden approval rating exceed 45%?" at "35"
3. Click **"Validate Probability"**
4. Get AI analysis in seconds!

## Troubleshooting

**Backend won't start?**
- Make sure you created the `.env` file
- Check that your API key is correct
- Ensure port 5000 is not in use

**Frontend won't connect?**
- Make sure backend is running first
- Check that backend is on port 5000
- Refresh the page

**"API key not configured" error?**
- Double-check your `.env` file has `GEMINI_API_KEY=your_key`
- Restart the backend server after editing `.env`

## What's Next?

- Try different events and correlations
- Experiment with the Polymarket API endpoint
- Customize the UI colors in `frontend/src/App.css`
- Add authentication for multi-user support

Enjoy! 🚀
