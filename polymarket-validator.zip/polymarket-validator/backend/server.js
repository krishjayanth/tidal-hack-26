const express = require('express');
const cors = require('cors');
const axios = require('axios');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'Server is running' });
});

// Analyze event endpoint
app.post('/api/analyze', async (req, res) => {
  try {
    const { targetEvent, targetPrice, relatedEvents } = req.body;

    // Validate input
    if (!targetEvent || !targetPrice || !relatedEvents || relatedEvents.length === 0) {
      return res.status(400).json({ 
        error: 'Missing required fields: targetEvent, targetPrice, and relatedEvents' 
      });
    }

    // Check for Gemini API key
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return res.status(500).json({ 
        error: 'Gemini API key not configured on server' 
      });
    }

    // Build the prompt
    const prompt = `You are a probability analysis expert. I need you to validate whether a Polymarket event's current price makes sense given related events.

TARGET EVENT: "${targetEvent}"
Current Price: ${targetPrice}%

RELATED EVENTS:
${relatedEvents.map((e, i) => `${i + 1}. "${e.title}" - Current Price: ${e.probability}%`).join('\n')}

Your task:
1. Analyze the correlations between the target event and the related events
2. Determine if the target event's ${targetPrice}% probability is REASONABLE, QUESTIONABLE, or UNREASONABLE given the related events' probabilities
3. Explain your reasoning in 2-3 clear paragraphs

Format your response as:
VERDICT: [REASONABLE/QUESTIONABLE/UNREASONABLE]

ANALYSIS:
[Your detailed analysis here]

Focus on logical relationships between events, not on predicting the "true" probability. We want to know if the price makes sense given the related market prices.`;

    // Call Gemini API
    const response = await axios.post(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${apiKey}`,
      {
        contents: [{
          parts: [{
            text: prompt
          }]
        }],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 1000,
        }
      },
      {
        headers: {
          'Content-Type': 'application/json',
        }
      }
    );

    const text = response.data.candidates[0].content.parts[0].text;

    // Parse the response
    const verdictMatch = text.match(/VERDICT:\s*(REASONABLE|QUESTIONABLE|UNREASONABLE)/i);
    const analysisMatch = text.match(/ANALYSIS:\s*([\s\S]+)/i);

    const result = {
      verdict: verdictMatch ? verdictMatch[1].toUpperCase() : 'UNKNOWN',
      analysis: analysisMatch ? analysisMatch[1].trim() : text
    };

    res.json(result);

  } catch (error) {
    console.error('Error analyzing event:', error.message);
    
    if (error.response?.data) {
      return res.status(error.response.status).json({
        error: error.response.data.error?.message || 'Failed to analyze event'
      });
    }
    
    res.status(500).json({ 
      error: 'Internal server error while analyzing event' 
    });
  }
});

// Fetch Polymarket events (optional - can be used to search for events)
app.get('/api/polymarket/search', async (req, res) => {
  try {
    const { query } = req.query;
    
    if (!query) {
      return res.status(400).json({ error: 'Search query required' });
    }

    // Using Polymarket's Gamma API to search markets
    const response = await axios.get('https://gamma-api.polymarket.com/markets', {
      params: {
        limit: 10,
        archived: false
      }
    });

    // Filter markets by query
    const markets = response.data
      .filter(market => 
        market.question.toLowerCase().includes(query.toLowerCase())
      )
      .slice(0, 10)
      .map(market => ({
        id: market.condition_id,
        question: market.question,
        // Polymarket prices are strings, convert to number
        probability: parseFloat(market.outcomes?.[0]?.price || 0) * 100
      }));

    res.json(markets);

  } catch (error) {
    console.error('Error fetching Polymarket data:', error.message);
    res.status(500).json({ 
      error: 'Failed to fetch Polymarket data' 
    });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`Gemini API key configured: ${process.env.GEMINI_API_KEY ? 'Yes' : 'No'}`);
});
