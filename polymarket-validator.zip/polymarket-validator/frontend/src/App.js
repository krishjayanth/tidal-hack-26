import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [targetEvent, setTargetEvent] = useState('');
  const [targetPrice, setTargetPrice] = useState('');
  const [relatedEventInput, setRelatedEventInput] = useState('');
  const [relatedEventPrice, setRelatedEventPrice] = useState('');
  const [relatedEvents, setRelatedEvents] = useState([]);
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const addRelatedEvent = () => {
    if (relatedEventInput.trim() && relatedEventPrice) {
      const price = parseFloat(relatedEventPrice);
      if (price >= 0 && price <= 100) {
        setRelatedEvents([
          ...relatedEvents,
          {
            title: relatedEventInput.trim(),
            probability: price,
          },
        ]);
        setRelatedEventInput('');
        setRelatedEventPrice('');
      }
    }
  };

  const removeRelatedEvent = (index) => {
    setRelatedEvents(relatedEvents.filter((_, i) => i !== index));
  };

  const analyzeEvent = async () => {
    if (!targetEvent.trim() || !targetPrice || relatedEvents.length === 0) {
      setError('Please fill in all fields and add at least one related event');
      return;
    }

    setLoading(true);
    setError(null);
    setAnalysis(null);

    try {
      const response = await axios.post('/api/analyze', {
        targetEvent,
        targetPrice: parseFloat(targetPrice),
        relatedEvents,
      });

      setAnalysis(response.data);
    } catch (err) {
      setError(
        err.response?.data?.error || 
        'Failed to analyze event. Please check your connection and try again.'
      );
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e, callback) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      callback();
    }
  };

  return (
    <div className="app">
      <header className="header">
        <div className="header-content">
          <div className="logo">
            <div className="logo-icon">P</div>
            <div className="logo-text">
              <h1>Polymarket Validator</h1>
              <p>AI-powered probability validation</p>
            </div>
          </div>
        </div>
      </header>

      <main className="container">
        <div className="info-box">
          <div className="info-box-title">How it works</div>
          <div className="info-box-text">
            Enter a target Polymarket event and its current price, then add related events. 
            Our AI will analyze the correlations to determine if the target event's price makes 
            sense given the related markets.
          </div>
        </div>

        <div className="grid grid-2">
          {/* Target Event Card */}
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Target Event</h2>
              <p className="card-subtitle">The event you want to validate</p>
            </div>

            <div className="form-group">
              <label className="form-label">Event Description</label>
              <textarea
                className="form-textarea"
                placeholder="e.g., Will Trump win the 2024 election?"
                value={targetEvent}
                onChange={(e) => setTargetEvent(e.target.value)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Current Market Price (%)</label>
              <input
                type="number"
                className="form-input"
                min="0"
                max="100"
                step="0.1"
                placeholder="e.g., 65.5"
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
              />
            </div>
          </div>

          {/* Related Events Card */}
          <div className="card">
            <div className="card-header">
              <h2 className="card-title">Related Events</h2>
              <p className="card-subtitle">Add correlated market events</p>
            </div>

            <div className="form-group">
              <label className="form-label">Event Description</label>
              <textarea
                className="form-textarea"
                placeholder="e.g., Will Republicans win the Senate?"
                value={relatedEventInput}
                onChange={(e) => setRelatedEventInput(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, addRelatedEvent)}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Current Market Price (%)</label>
              <input
                type="number"
                className="form-input"
                min="0"
                max="100"
                step="0.1"
                placeholder="e.g., 72.3"
                value={relatedEventPrice}
                onChange={(e) => setRelatedEventPrice(e.target.value)}
                onKeyPress={(e) => handleKeyPress(e, addRelatedEvent)}
              />
            </div>

            <button className="btn btn-secondary btn-block" onClick={addRelatedEvent}>
              Add Related Event
            </button>

            {relatedEvents.length > 0 && (
              <div className="events-list" style={{ marginTop: '24px' }}>
                {relatedEvents.map((event, index) => (
                  <div key={index} className="event-item">
                    <div className="event-content">
                      <div className="event-title">{event.title}</div>
                      <div className="event-probability">{event.probability}%</div>
                    </div>
                    <div className="event-actions">
                      <button
                        className="btn btn-danger"
                        onClick={() => removeRelatedEvent(index)}
                        style={{ padding: '6px 12px', fontSize: '13px' }}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {relatedEvents.length === 0 && (
              <div className="empty-state" style={{ marginTop: '24px' }}>
                <div className="empty-state-icon">📊</div>
                <div className="empty-state-text">
                  No related events added yet
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Analyze Button */}
        <div className="card">
          <button
            className="btn btn-primary btn-block"
            onClick={analyzeEvent}
            disabled={loading || !targetEvent || !targetPrice || relatedEvents.length === 0}
          >
            {loading ? 'Analyzing...' : 'Validate Probability'}
          </button>
        </div>

        {/* Error Display */}
        {error && (
          <div className="card">
            <div className="error-container">
              <div className="error-title">Error</div>
              <div>{error}</div>
            </div>
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <div className="card">
            <div className="loading-container">
              <div className="spinner"></div>
              <div className="loading-text">Analyzing event correlations...</div>
            </div>
          </div>
        )}

        {/* Analysis Results */}
        {analysis && !loading && (
          <div className="card">
            <div className="analysis-header">
              <h2 className="card-title">Analysis Results</h2>
              <div className={`verdict-badge ${analysis.verdict.toLowerCase()}`}>
                {analysis.verdict === 'REASONABLE' && '✓ '}
                {analysis.verdict === 'QUESTIONABLE' && '⚠ '}
                {analysis.verdict === 'UNREASONABLE' && '✗ '}
                {analysis.verdict}
              </div>
            </div>
            <div className="analysis-text">{analysis.analysis}</div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
