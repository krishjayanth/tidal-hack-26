# Polymarket Probability Validator

AI-powered web application that validates Polymarket event probabilities using related events and Google Gemini LLM.

## Overview

This application answers the question: **"Given these related markets, does Event X's current price make sense?"**

Instead of predicting the "true probability," it analyzes correlations between events to validate whether a target event's Polymarket price is reasonable given related market prices.

## Architecture

- **Frontend**: React (Create React App)
- **Backend**: Node.js + Express
- **AI**: Google Gemini API
- **Data Source**: Polymarket Gamma API

## Features

- ✅ Manual event selection with price input
- ✅ AI-powered correlation analysis using Google Gemini
- ✅ Clear verdicts: REASONABLE, QUESTIONABLE, or UNREASONABLE
- ✅ Professional fintech-inspired UI (white & gold color scheme)
- ✅ Secure API key handling (server-side only)

## Setup Instructions

### Prerequisites

- Node.js 16+ and npm
- Google Gemini API key (get free at [https://aistudio.google.com](https://aistudio.google.com))

### Backend Setup

1. Navigate to the backend directory:
```bash
cd backend
```

2. Install dependencies:
```bash
npm install
```

3. Create a `.env` file (copy from `.env.example`):
```bash
cp .env.example .env
```

4. Edit `.env` and add your Gemini API key:
```
GEMINI_API_KEY=your_actual_api_key_here
PORT=5000
```

5. Start the backend server:
```bash
npm start
```

The backend will run on `http://localhost:5000`

### Frontend Setup

1. Open a new terminal and navigate to the frontend directory:
```bash
cd frontend
```

2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm start
```

The frontend will automatically open at `http://localhost:3000`

## Usage

1. **Enter Target Event**: Add the Polymarket event you want to validate and its current market price
2. **Add Related Events**: Input correlated events with their current prices
3. **Validate**: Click "Validate Probability" to get AI analysis
4. **Review Results**: See the verdict (REASONABLE/QUESTIONABLE/UNREASONABLE) with detailed reasoning

### Example

**Target Event:** "Will Trump win the 2024 election?" - 65%

**Related Events:**
- "Will Republicans win the Senate?" - 72%
- "Will Biden's approval rating be above 45%?" - 38%
- "Will there be a recession in 2024?" - 55%

The AI will analyze these correlations and determine if 65% makes sense given the related market prices.

## API Endpoints

### Backend API

- `GET /api/health` - Health check
- `POST /api/analyze` - Analyze event probability
  - Body: `{ targetEvent, targetPrice, relatedEvents }`
- `GET /api/polymarket/search?query=...` - Search Polymarket events (optional)

## Project Structure

```
polymarket-validator/
├── backend/
│   ├── server.js           # Express server
│   ├── package.json
│   ├── .env.example
│   └── .env               # Your API keys (git-ignored)
├── frontend/
│   ├── public/
│   │   └── index.html
│   ├── src/
│   │   ├── App.js         # Main React component
│   │   ├── App.css        # Component styles
│   │   ├── index.js       # React entry point
│   │   └── index.css      # Global styles
│   └── package.json
└── README.md
```

## Development

### Backend Development
```bash
cd backend
npm run dev  # Uses nodemon for auto-reload
```

### Frontend Development
```bash
cd frontend
npm start    # Hot-reload enabled by default
```

## Production Build

### Build Frontend
```bash
cd frontend
npm run build
```

The optimized production build will be in `frontend/build/`

### Deploy
You can serve the built frontend from the Express backend by adding:
```javascript
app.use(express.static(path.join(__dirname, '../frontend/build')));
```

## Security Notes

- ✅ API key stored server-side only (never exposed to client)
- ✅ CORS enabled for development
- ✅ Input validation on backend
- ⚠️ For production: Add rate limiting, authentication, and proper error handling

## License

MIT
